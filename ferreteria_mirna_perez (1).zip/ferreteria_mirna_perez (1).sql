-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-06-2023 a las 08:18:24
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ferreteria_mirna_perez`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `activos`
--

CREATE TABLE `activos` (
  `Id_activos` int(11) NOT NULL,
  `nombre_activo` varchar(255) NOT NULL,
  `valor` int(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `contraseña` varchar(50) NOT NULL,
  `correo` varchar(254) NOT NULL,
  `telefono` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`id`, `usuario`, `contraseña`, `correo`, `telefono`) VALUES
(12, 'Edwin', 'edwin0306', 'edwin.noviembre.0306@gmail.com', '89569717'),
(13, 'edwin', '123', 'edwin.noviembre@gmail.com', '89569717'),
(14, 'juan', '123', 'juan@gmail.com', '89569717'),
(15, '123123', '12323', '1233', '1233'),
(16, 'juan', '123', 'juan@gmail.com', '89569717');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `blance general`
--

CREATE TABLE `blance general` (
  `id` int(11) NOT NULL,
  `tipo de cuenta` varchar(255) NOT NULL,
  `1` varchar(80) NOT NULL,
  `2` varchar(80) NOT NULL,
  `3` varchar(80) NOT NULL,
  `4` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `blance general`
--

INSERT INTO `blance general` (`id`, `tipo de cuenta`, `1`, `2`, `3`, `4`) VALUES
(1, 'Activo Cirulante', '', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado de resultado`
--

CREATE TABLE `estado de resultado` (
  `id` int(11) NOT NULL,
  `Cuenta` varchar(100) NOT NULL,
  `1` varchar(80) NOT NULL,
  `2` varchar(80) NOT NULL,
  `3` varchar(80) NOT NULL,
  `4` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `estado de resultado`
--

INSERT INTO `estado de resultado` (`id`, `Cuenta`, `1`, `2`, `3`, `4`) VALUES
(1, 'Ventas totales', '', '', '955,661.30', ''),
(2, 'Ventas netas', '', '', '', '955,661.30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado de variacion`
--

CREATE TABLE `estado de variacion` (
  `id` int(11) NOT NULL,
  `cuenta` varchar(100) NOT NULL,
  `1` varchar(80) NOT NULL,
  `2` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `estado de variacion`
--

INSERT INTO `estado de variacion` (`id`, `cuenta`, `1`, `2`) VALUES
(1, 'Capital social', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `flujo de efectivo`
--

CREATE TABLE `flujo de efectivo` (
  `id` int(11) NOT NULL,
  `cuenta` varchar(100) NOT NULL,
  `1` varchar(80) NOT NULL,
  `2` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `flujo de efectivo`
--

INSERT INTO `flujo de efectivo` (`id`, `cuenta`, `1`, `2`) VALUES
(1, 'Flujo de efectivo de actividad de operacion', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `Id` int(11) NOT NULL,
  `Producto` varchar(80) NOT NULL,
  `Costo` decimal(50,0) NOT NULL,
  `Coddigo de producto` int(50) NOT NULL,
  `Cantidad` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`Id`, `Producto`, `Costo`, `Coddigo de producto`, `Cantidad`) VALUES
(66, 'cemento', 405, 8004, 100),
(67, 'cemento', 405, 8004, 100),
(68, 'cemento', 405, 8004, 100),
(69, 'cemento', 405, 8004, 100),
(70, 'cemento', 405, 8004, 100),
(71, 'cemento', 405, 8004, 100),
(72, 'cemento', 405, 8004, 100),
(73, 'cemento', 405, 8004, 100),
(74, 'cemento', 405, 8004, 100),
(75, 'cemento', 405, 8004, 100),
(76, 'cemento', 405, 8004, 100),
(77, 'cemento', 405, 8004, 100),
(78, 'cemento', 405, 8004, 100),
(79, 'cemento', 405, 8004, 100),
(80, 'cemento', 405, 8004, 100),
(81, 'cemento', 405, 8004, 100),
(82, 'cemento', 405, 8004, 100),
(83, 'cemento', 405, 8004, 100),
(84, 'cemento', 405, 8004, 100),
(85, 'cemento', 405, 8004, 100),
(86, 'cemento', 405, 8004, 100),
(87, 'cemento', 405, 8004, 100);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `codigo de venta` int(45) NOT NULL,
  `producto` varchar(255) NOT NULL,
  `precio` int(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `activos`
--
ALTER TABLE `activos`
  ADD PRIMARY KEY (`Id_activos`);

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `blance general`
--
ALTER TABLE `blance general`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado de resultado`
--
ALTER TABLE `estado de resultado`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado de variacion`
--
ALTER TABLE `estado de variacion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `flujo de efectivo`
--
ALTER TABLE `flujo de efectivo`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`Id`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `activos`
--
ALTER TABLE `activos`
  MODIFY `Id_activos` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `administrador`
--
ALTER TABLE `administrador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `blance general`
--
ALTER TABLE `blance general`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `estado de resultado`
--
ALTER TABLE `estado de resultado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `estado de variacion`
--
ALTER TABLE `estado de variacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `flujo de efectivo`
--
ALTER TABLE `flujo de efectivo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
