/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ferreteria.dao;

import Clases.Lista_producto;
import Clases.Productos;
import com.login.lib.Registro;
import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;


public class Conexion {
   
    String bd = "ferreteria_mirna_perez";  // se declara la variable bd y se ingresa el nombre de la BD
    String url = "jdbc:mysql://localhost:3306/";    //Se declara la variable url y se ingresa la localizacion de la BD
    String user = "root"; 
    String password = "";
    String driver = "com.mysql.cj.jdbc.Driver";
    Connection cx;
    PreparedStatement ps;

    public Conexion(String bd) {
        this.bd = bd;
    }

    public Connection conectar (){
    
        try {
            Class.forName(driver);
            cx =DriverManager.getConnection(url + bd, user, password);
            System.out.println("se conecto a la BD " + bd);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("no se conecto a la BD " + bd);
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cx;
    }
    
   
    public void agregarUsuario(String usuario, String contraseña, String correo, String telefono) {      
        Connection conexion = null;
       try{
           
           
           Class.forName(driver);
           conexion = DriverManager.getConnection(url + bd  ,user, password);
           
        String sql = "INSERT INTO `administrador` (`id`, `usuario`, `contraseña`, `correo`, `telefono`) VALUES (NULL, '"+usuario +"', '"+contraseña+"', '"+correo+"', '"+telefono+"');";
            Statement statement = conexion.createStatement();
            statement.execute(sql);
        
       }catch(Exception ex){
       Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
       }
    } 
   
    public void consultarUsuario(){
         // Conexion datab = new Conexion();
    }
    
     public void agregarProducto ( String producto, String precio, String codigo, String cantidad) {      
       Connection conexion = null;
       try{ 
           Class.forName(driver);
           conexion = DriverManager.getConnection(url+bd ,user, password);
           
        String sql =  "INSERT INTO `productos` (`Id`, `Producto`, `Costo`, `Coddigo de producto`, `Cantidad`) VALUES (NULL, '"+producto+"', '"+precio+"', '"+codigo+"', '"+cantidad+"');";
            Statement statement = conexion.createStatement();
            statement.execute(sql);
        
       }catch(Exception ex){
       Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
       }
    }     
     
      public void agregarFlujodeEfectivo ( String Cuenta, String uno, String dos) {      
       Connection conexion = null;
       try{ 
           Class.forName(driver);
           conexion = DriverManager.getConnection(url+bd ,user, password);
           
        String sql =  "INSERT INTO `flujo de efectivo` (`id`, `cuenta`, `1`, `2`) VALUES (NULL, '"+Cuenta+"', '"+uno+"', '"+dos+"');";
            Statement statement = conexion.createStatement();
            statement.execute(sql);
        
       }catch(Exception ex){
       Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
       }
    }     
      
      public void agregarEstadodeVariacion ( String Cuenta, String uno, String dos) {      
       Connection conexion = null;
       try{ 
           Class.forName(driver);
           conexion = DriverManager.getConnection(url+bd ,user, password);
           
        String sql =  "INSERT INTO `estado de variacion` (`id`, `cuenta`, `1`, `2`) VALUES (NULL, '"+Cuenta+"', '"+uno+"', '"+dos+"');";
            Statement statement = conexion.createStatement();
            statement.execute(sql);
        
       }catch(Exception ex){
       Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
       }
    }     
     
     public void agregarEstadoResultado ( String cuenta, String uno, String dos, String tres, String cuatro) {      
       Connection conexion = null;
       try{ 
           Class.forName(driver);
           conexion = DriverManager.getConnection(url+bd ,user, password);
           
        String sql =  "INSERT INTO `estado de resultado` (`id`, `Cuenta`, `1`, `2`, `3`, `4`) VALUES (NULL, '"+cuenta+"', '"+uno+"', '"+dos+"', '"+tres+"', '"+cuatro+"');";
            Statement statement = conexion.createStatement();
            statement.execute(sql);
        
       }catch(Exception ex){
       Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
       }
    }     
     
      public void agregarBalanceGeneral ( String cuenta, String uno, String dos, String tres, String cuatro) {      
       Connection conexion = null;
       try{ 
           Class.forName(driver);
           conexion = DriverManager.getConnection(url+bd ,user, password);
           
        String sql =  "INSERT INTO `blance general` (`id`, `tipo de cuenta`, `1`, `2`, `3`, `4`) VALUES (NULL, '"+cuenta+"', '"+uno+"', '"+dos+"', '"+tres+"', '"+cuatro+"');";
            Statement statement = conexion.createStatement();
            statement.execute(sql);
        
       }catch(Exception ex){
       Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
      
      public void EliminarProducto ( String producto, String precio, String codigo, String cantidad) {      
        Connection conexion = null;
        Registro r = new Registro();
       try{
           
           
           Class.forName(driver);
           conexion = DriverManager.getConnection(url + bd  ,user, password);
           
        String sql =  "DELETE FROM productos WHERE `productos`.`Id` = ";
            Statement statement = conexion.createStatement();
            statement.execute(sql);
        
       }catch(Exception ex){
       Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
       
           
       }
    }     
        public boolean EliminarProductos(String producto){
       String sql = "DELETE FROM productos WHERE `productos`.`Id` =  ?";
       try {
           ps = cx.prepareStatement(sql);
           ps.setString(1, producto);
           ps.execute();
           return true;
       } catch (SQLException e) {
           System.out.println(e.toString());
           return false;
       }finally{
           try {
               cx.close();
           } catch (SQLException ex) {
               System.out.println(ex.toString());
           }
       }
   }
    
        public void RellenarComboBOx(String tabla, String valor, JComboBox combo){
            String sql = "SELECT Producto FROM productos";
            Statement st;
            Conexion con = new Conexion(bd);
            Connection conexion = con.conectar();
            try
            {
            st = conexion.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                combo.addItem(rs.getString(valor));
            }
             
            }catch(Exception ex){
              Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            }
         
    }
    
     
    public void obtenerPrecioProducto(String nombreProducto) throws SQLException {
        double Costo = 0.0;

        try (Connection conn = conectar();
             PreparedStatement stmt = conn.prepareStatement("SELECT Costo FROM productos WHERE Producto = ?");
        ) {
            stmt.setString(1, nombreProducto);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Costo = rs.getDouble("Costo");
                }
                
            }
        
        }

        
    }
        
        
        
        
    public void desconectar(){
        try {
            cx.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
        public static void main(String[] args){
        
            Conexion Conexion = new Conexion("ferreteria_mirna_perez");
            Conexion.conectar();
       
        }
  
    
   
     }
