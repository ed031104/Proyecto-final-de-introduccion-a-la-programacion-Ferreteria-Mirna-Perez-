/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.ferreteria.views;

import Clases.LIsta_precio;
import Clases.Lista_producto;
import Clases.Precio;
import com.ferreteria.dao.Conexion;
import java.awt.Color;
import java.awt.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;

/**
 *
 * @author edwin
 */
public class Ventas extends javax.swing.JPanel {

    /**
     * Creates new form panel
     */
    Conexion c = new Conexion("ferreteria_mirna_perez");
    public Ventas() {
        initComponents();
        setOpaque(false);
        EncabezadoPAnel.setBackground(new Color(127,139,145));
        cargarCombo(combo_producto);
        
    }   

   
    
   
     public void contarProductos (){
  /*  int filas=combo_producto;
    TxtTotal.setText(" "+filas+ " PRODUCTOS");
    */    
    }
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BG = new javax.swing.JPanel();
        Tabla = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        EliminarBtn = new javax.swing.JButton();
        LimpiarBtn = new javax.swing.JButton();
        combo_producto = new javax.swing.JComboBox<>();
        IncrementadorBtn = new javax.swing.JSpinner();
        AgregarBtn = new javax.swing.JButton();
        EditarBtn = new javax.swing.JButton();
        TotalPanel = new javax.swing.JPanel();
        TxtTotal = new javax.swing.JLabel();
        TextoTotal = new javax.swing.JLabel();
        EncabezadoPAnel = new javax.swing.JPanel();
        TxtVentas = new javax.swing.JLabel();
        IConVEntas = new javax.swing.JLabel();
        Atras = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        PRecioTxt = new javax.swing.JLabel();
        Precio = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        BG.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Tabla.setViewportView(jTable1);

        EliminarBtn.setText("Eliminar");

        LimpiarBtn.setText("limpiar");

        combo_producto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        combo_producto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_productoActionPerformed(evt);
            }
        });

        IncrementadorBtn.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        IncrementadorBtn.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                IncrementadorBtnStateChanged(evt);
            }
        });

        AgregarBtn.setText("Agregar");
        AgregarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarBtnActionPerformed(evt);
            }
        });

        EditarBtn.setText("Editar");

        TxtTotal.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TxtTotal.setText("000,000 $");

        TextoTotal.setFont(new java.awt.Font("Roboto Black", 1, 14)); // NOI18N
        TextoTotal.setText("TOTAL");

        javax.swing.GroupLayout TotalPanelLayout = new javax.swing.GroupLayout(TotalPanel);
        TotalPanel.setLayout(TotalPanelLayout);
        TotalPanelLayout.setHorizontalGroup(
            TotalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalPanelLayout.createSequentialGroup()
                .addContainerGap(133, Short.MAX_VALUE)
                .addComponent(TxtTotal)
                .addGap(16, 16, 16))
            .addGroup(TotalPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TextoTotal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TotalPanelLayout.setVerticalGroup(
            TotalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TextoTotal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(TxtTotal)
                .addContainerGap())
        );

        TxtVentas.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TxtVentas.setForeground(new java.awt.Color(255, 255, 255));
        TxtVentas.setText("VENTAS");

        IConVEntas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-dinero-40.png"))); // NOI18N

        Atras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-volver-25.png"))); // NOI18N
        Atras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AtrasMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout EncabezadoPAnelLayout = new javax.swing.GroupLayout(EncabezadoPAnel);
        EncabezadoPAnel.setLayout(EncabezadoPAnelLayout);
        EncabezadoPAnelLayout.setHorizontalGroup(
            EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(Atras)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(IConVEntas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TxtVentas)
                .addGap(30, 30, 30))
        );
        EncabezadoPAnelLayout.setVerticalGroup(
            EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                .addGroup(EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(Atras))
                    .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(TxtVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(IConVEntas, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("SUBTOTAL");

        jLabel2.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("IVA");

        jLabel3.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("$ 0.00 NIC");

        jLabel4.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("$ 0.00 NIC");

        PRecioTxt.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        PRecioTxt.setForeground(new java.awt.Color(0, 0, 0));
        PRecioTxt.setText("Precio:");

        Precio.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        Precio.setForeground(new java.awt.Color(0, 0, 0));
        Precio.setText("$ 0.00 NIC");

        jLabel5.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Importe:");

        jLabel6.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("$ 0.00 NIC");

        javax.swing.GroupLayout BGLayout = new javax.swing.GroupLayout(BG);
        BG.setLayout(BGLayout);
        BGLayout.setHorizontalGroup(
            BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(EncabezadoPAnel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(BGLayout.createSequentialGroup()
                .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, BGLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(TotalPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, BGLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(combo_producto, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(IncrementadorBtn)
                            .addGroup(BGLayout.createSequentialGroup()
                                .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(BGLayout.createSequentialGroup()
                                            .addGap(30, 30, 30)
                                            .addComponent(LimpiarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BGLayout.createSequentialGroup()
                                            .addComponent(EditarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(EliminarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, BGLayout.createSequentialGroup()
                                            .addComponent(PRecioTxt)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(Precio))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, BGLayout.createSequentialGroup()
                                            .addComponent(jLabel5)
                                            .addGap(18, 18, 18)
                                            .addComponent(jLabel6))))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(15, 15, 15)
                .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Tabla)
                    .addGroup(BGLayout.createSequentialGroup()
                        .addComponent(AgregarBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(49, 49, 49)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addGap(98, 98, 98)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addGap(109, 109, 109)))
                .addGap(24, 24, 24))
        );
        BGLayout.setVerticalGroup(
            BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BGLayout.createSequentialGroup()
                .addComponent(EncabezadoPAnel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BGLayout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(combo_producto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(IncrementadorBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(58, 58, 58)
                        .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(EditarBtn)
                            .addComponent(EliminarBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LimpiarBtn)
                        .addGap(44, 44, 44)
                        .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PRecioTxt)
                            .addComponent(Precio))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE))
                    .addGroup(BGLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(Tabla, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TotalPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(AgregarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel1)
                        .addComponent(jLabel3)
                        .addComponent(jLabel4)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void AgregarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AgregarBtnActionPerformed

    private void AtrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AtrasMouseClicked
        Prin p = new Prin();
        p.setVisible(true);
        
    }//GEN-LAST:event_AtrasMouseClicked

    private void combo_productoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_productoActionPerformed
        
    
    }//GEN-LAST:event_combo_productoActionPerformed

    private void IncrementadorBtnStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_IncrementadorBtnStateChanged
    
    }//GEN-LAST:event_IncrementadorBtnStateChanged

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AgregarBtn;
    private javax.swing.JLabel Atras;
    private javax.swing.JPanel BG;
    private javax.swing.JButton EditarBtn;
    private javax.swing.JButton EliminarBtn;
    private javax.swing.JPanel EncabezadoPAnel;
    private javax.swing.JLabel IConVEntas;
    private javax.swing.JSpinner IncrementadorBtn;
    private javax.swing.JButton LimpiarBtn;
    private javax.swing.JLabel PRecioTxt;
    private javax.swing.JLabel Precio;
    private javax.swing.JScrollPane Tabla;
    private javax.swing.JLabel TextoTotal;
    private javax.swing.JPanel TotalPanel;
    private javax.swing.JLabel TxtTotal;
    private javax.swing.JLabel TxtVentas;
    private javax.swing.JComboBox<String> combo_producto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

    private void cargarCombo(JComboBox c) {
            Conexion con = new Conexion("ferreteria_mirna_perez");
            Connection cn = con.conectar();
        
        DefaultComboBoxModel combo = new DefaultComboBoxModel();
        c.setModel(combo);
        Lista_producto lp = new Lista_producto();
        try{
        Statement st = cn.createStatement();
        ResultSet rs = st.executeQuery("SELECT Producto FROM productos");
        while(rs.next()){
            Clases.Productos pro = new Clases.Productos();
            pro.setProducto(rs.getString(1));
            lp.AgregarProductos(pro);
            combo.addElement(pro.getProducto());
            System.out.println("EXITO");
            
        }}
        catch(Exception ex){
         Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("N se puede mostrar");
        }
    }

    
  

        
}