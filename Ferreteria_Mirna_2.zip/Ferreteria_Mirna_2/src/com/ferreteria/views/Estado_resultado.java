/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.ferreteria.views;

import Clases.Lista_producto;
import com.ferreteria.dao.Conexion;
import com.mysql.cj.xdevapi.Statement;
import com.sun.jdi.connect.spi.Connection;
import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;


public class Estado_resultado extends javax.swing.JPanel {
    
    

    DefaultTableModel dtm = new DefaultTableModel();
    Conexion con = new Conexion("ferreteria_mirna_perez");
   
    
    public Estado_resultado() {
        initComponents();
        setOpaque(false);
        EncabezadoPAnel.setBackground(new Color(237,162,0));
        String [] tittulo = new String[] {"Cuenta", "1", "2", "3", "4"}; // se le pone los titulos a la tabla
        dtm.setColumnIdentifiers(tittulo);
        visor.setModel(dtm);
        mostrar("estado de resultado");
    }
    
    
    public void mostrar(String tabla){
     
    String sql = "SELECT * FROM `estado de resultado` " ;
   // Statement st;
      Conexion con = new Conexion("ferreteria_mirna_perez");
    java.sql.Connection cn = con.conectar();  
    System.out.println(sql);
    DefaultTableModel model = new DefaultTableModel();
    
    model.addColumn("id");
   model.addColumn("cuenta");
   model.addColumn("1");
   model.addColumn("2");
   model.addColumn("3");
   model.addColumn("4");
   visor.setModel(model);
    
   String [] datos = new String[6];
  
   try{
      java.sql.Statement st = cn.createStatement();
       ResultSet rs = st.executeQuery(sql);
       while(rs.next()){
           datos[0]=rs.getString(1);
           datos[1]=rs.getString(2);
           datos[2]=rs.getString(3);
           datos[3]=rs.getString(4);
           datos[4]=rs.getString(5);
           datos[5]=rs.getString(6);
           model.addRow(datos);
       }
     }catch(SQLException e){
         Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, e);
     }
  }
    
    public void Eliminar (){
    int fila = visor.getSelectedRow();
    java.sql.Connection cn = con.conectar(); 
    String valor = visor.getValueAt(fila, 0).toString();
  
        try {
         PreparedStatement elimi = cn.prepareStatement("DELETE * FROM `estado de resultado` WHERE id='"+valor+"'");
            elimi.executeUpdate();
            mostrar("estado de resultado");
        } catch (Exception e) {
             Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
  
    private void ShowJpanel(JPanel jp) {
     
 
    jp.setVisible(true); // hace visible al panel
    jp.setSize(684, 500); // da el tamaño del panel
    jp.setLocation(0, 0); // centra el panel

    Backg.removeAll(); // esto elimina lo que se encontraba en content
    Backg.setLayout(new BorderLayout()); // Establecer el LayoutManager del contenedor Content en BorderLayout
    Backg.add(jp, BorderLayout.CENTER); // Agregar el panel principal al centro del contenedor Content
    jp.setPreferredSize(Backg.getSize()); // Asegurarse de que el panel principal ocupe todo el espacio disponible

    Backg.revalidate(); // notifica al contenedor Content que su diseño ha cambiado y necesita ser validado.
    Backg.repaint(); // repinta el contenedor Content para que se muestren los cambios realizados.


     }
    
          
    void agregar(){
    dtm.addRow(new Object[]{
       CuentaTxt.getText()  , unoTxt.getText(), dostxt.getText(), trestxt.getText(), cuatrotxt.getText()
    });
    }
    
   
    
    
    
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Backg = new javax.swing.JPanel();
        Tabla = new javax.swing.JScrollPane();
        visor = new javax.swing.JTable();
        EliminarBtn = new javax.swing.JButton();
        AgregarBtn = new javax.swing.JButton();
        EncabezadoPAnel = new javax.swing.JPanel();
        TxtVentas = new javax.swing.JLabel();
        Atras = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        TxtProducto = new javax.swing.JLabel();
        TxtPrecio = new javax.swing.JLabel();
        TxtCodigo = new javax.swing.JLabel();
        unoTxt = new javax.swing.JTextField();
        dostxt = new javax.swing.JTextField();
        trestxt = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        cuatrotxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        CuentaTxt = new javax.swing.JTextField();

        Backg.setBackground(new java.awt.Color(255, 255, 255));

        visor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Producto", "Precio", "Codigo de producto"
            }
        ));
        Tabla.setViewportView(visor);

        EliminarBtn.setText("Eliminar");
        EliminarBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EliminarBtnMouseClicked(evt);
            }
        });
        EliminarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarBtnActionPerformed(evt);
            }
        });

        AgregarBtn.setText("Agregar");
        AgregarBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AgregarBtnMouseClicked(evt);
            }
        });
        AgregarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarBtnActionPerformed(evt);
            }
        });

        TxtVentas.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TxtVentas.setForeground(new java.awt.Color(255, 255, 255));
        TxtVentas.setText("Estado de resultado");

        Atras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-volver-25.png"))); // NOI18N
        Atras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AtrasMouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-resultado-40.png"))); // NOI18N

        javax.swing.GroupLayout EncabezadoPAnelLayout = new javax.swing.GroupLayout(EncabezadoPAnel);
        EncabezadoPAnel.setLayout(EncabezadoPAnelLayout);
        EncabezadoPAnelLayout.setHorizontalGroup(
            EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(Atras)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 598, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TxtVentas)
                .addGap(14, 14, 14))
        );
        EncabezadoPAnelLayout.setVerticalGroup(
            EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TxtVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(Atras)
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TxtProducto.setText("1. casilla:");

        TxtPrecio.setText("2. casilla:");

        TxtCodigo.setText("3. casilla");

        unoTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unoTxtActionPerformed(evt);
            }
        });

        jLabel1.setText("4. casilla");

        cuatrotxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cuatrotxtActionPerformed(evt);
            }
        });

        jLabel3.setText("Cuenta:");

        javax.swing.GroupLayout BackgLayout = new javax.swing.GroupLayout(Backg);
        Backg.setLayout(BackgLayout);
        BackgLayout.setHorizontalGroup(
            BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(EncabezadoPAnel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(BackgLayout.createSequentialGroup()
                .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BackgLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(EliminarBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
                            .addComponent(AgregarBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)))
                    .addGroup(BackgLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TxtCodigo)
                            .addComponent(TxtPrecio)
                            .addComponent(TxtProducto)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(unoTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                            .addComponent(dostxt)
                            .addComponent(trestxt)
                            .addComponent(cuatrotxt)
                            .addComponent(CuentaTxt))
                        .addGap(15, 15, 15)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Tabla, javax.swing.GroupLayout.DEFAULT_SIZE, 564, Short.MAX_VALUE)
                .addGap(23, 23, 23))
        );
        BackgLayout.setVerticalGroup(
            BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BackgLayout.createSequentialGroup()
                .addComponent(EncabezadoPAnel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BackgLayout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(CuentaTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TxtProducto)
                            .addComponent(unoTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TxtPrecio)
                            .addComponent(dostxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(trestxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TxtCodigo))
                        .addGap(18, 18, 18)
                        .addGroup(BackgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cuatrotxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                        .addComponent(AgregarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(EliminarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(BackgLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Tabla, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Backg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Backg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void AgregarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarBtnActionPerformed
       
    }//GEN-LAST:event_AgregarBtnActionPerformed

    private void AtrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AtrasMouseClicked
        ShowJpanel(new Reporte());
    }//GEN-LAST:event_AtrasMouseClicked

    private void unoTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unoTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_unoTxtActionPerformed

    private Set<String> productosRegistrados = new HashSet<String>();
    
    private void AgregarBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AgregarBtnMouseClicked
  
    String cuenta = CuentaTxt.getText().trim();
    String uno = unoTxt.getText();
    String dos = dostxt.getText();
    String tres = trestxt.getText();
    String cuatro = cuatrotxt.getText();
    
    if (cuenta.isEmpty() && uno.isEmpty() && dos.isEmpty()){
        JOptionPane.showMessageDialog(null, "No se admiten casillas vacias.");
    // Verificar si el producto ya está registrado
    }
     else{
        Conexion c = new Conexion("ferreteria_mirna_perez");
        c.agregarEstadoResultado(cuenta, uno, dos, tres, cuatro);
        agregar();
         mostrar("estado de resultado");
         
    }
    
    
    }//GEN-LAST:event_AgregarBtnMouseClicked

    private void cuatrotxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cuatrotxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cuatrotxtActionPerformed

    private void EliminarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarBtnActionPerformed
        
      

    }//GEN-LAST:event_EliminarBtnActionPerformed

    private void EliminarBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EliminarBtnMouseClicked
        Eliminar();
    }//GEN-LAST:event_EliminarBtnMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AgregarBtn;
    private javax.swing.JLabel Atras;
    private javax.swing.JPanel Backg;
    private javax.swing.JTextField CuentaTxt;
    private javax.swing.JButton EliminarBtn;
    private javax.swing.JPanel EncabezadoPAnel;
    private javax.swing.JScrollPane Tabla;
    private javax.swing.JLabel TxtCodigo;
    private javax.swing.JLabel TxtPrecio;
    private javax.swing.JLabel TxtProducto;
    private javax.swing.JLabel TxtVentas;
    private javax.swing.JTextField cuatrotxt;
    private javax.swing.JTextField dostxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField trestxt;
    private javax.swing.JTextField unoTxt;
    private javax.swing.JTable visor;
    // End of variables declaration//GEN-END:variables

   
   
    
}
