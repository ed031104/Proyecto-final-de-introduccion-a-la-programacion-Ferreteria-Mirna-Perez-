/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.ferreteria.views;

import Clases.Lista_producto;
import com.ferreteria.dao.Conexion;
import com.mysql.cj.xdevapi.Statement;
import com.sun.jdi.connect.spi.Connection;
import java.awt.Color;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Compras extends javax.swing.JPanel {
    
    

    DefaultTableModel dtm = new DefaultTableModel();
    Conexion con = new Conexion("ferreteria_mirna_perez");
   
    
    public Compras() {
        initComponents();
        setOpaque(false);
        EncabezadoPAnel.setBackground(new Color(237,162,0));
        String [] tittulo = new String[] {"Cantidad", "Producto", "Precio", "Codigo de producto"}; // se le pone los titulos a la tabla
        dtm.setColumnIdentifiers(tittulo);
        visor.setModel(dtm);
        mostrar("productos");
        contarProductos();
    }
    
    
    public void mostrar(String tabla){
     
    String sql = "SELECT * FROM `productos` " ;
   // Statement st;
      Conexion con = new Conexion("ferreteria_mirna_perez");
    java.sql.Connection cn = con.conectar();  
    System.out.println(sql);
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Id");
   model.addColumn("Producto");
   model.addColumn("Precio");
   model.addColumn("Codigo de producto");
   visor.setModel(model);
    
   String [] datos = new String[5];
  
   try{
      java.sql.Statement st = cn.createStatement();
       ResultSet rs = st.executeQuery(sql);
       while(rs.next()){
           datos[0]=rs.getString(1);
           datos[1]=rs.getString(2);
           datos[2]=rs.getString(3);
           datos[3]=rs.getString(4);
           datos[4]=rs.getString(5);
           model.addRow(datos);
       }
     }catch(SQLException e){
         Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, e);
     }
  }
    
    public void Eliminar (){
    int fila = visor.getSelectedRow();
    java.sql.Connection cn = con.conectar(); 
    String valor = visor.getValueAt(fila, 0).toString();
  
        try {
         PreparedStatement elimi = cn.prepareStatement("DELETE FROM productos WHERE id='"+valor+"'");
            elimi.executeUpdate();
        } catch (Exception e) {
        }
    }
    

    public void contarProductos (){
    int filas=visor.getRowCount();
    TxtTotal.setText(" "+filas+ " PRODUCTOS");
        
    }
    
    
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BG = new javax.swing.JPanel();
        Tabla = new javax.swing.JScrollPane();
        visor = new javax.swing.JTable();
        TotalPanel = new javax.swing.JPanel();
        TxtTotal = new javax.swing.JLabel();
        TextoTotal = new javax.swing.JLabel();
        EncabezadoPAnel = new javax.swing.JPanel();
        TxtVentas = new javax.swing.JLabel();
        Atras = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        BG.setBackground(new java.awt.Color(255, 255, 255));

        visor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Producto", "Precio", "Codigo de producto"
            }
        ));
        Tabla.setViewportView(visor);

        TxtTotal.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TxtTotal.setText("9 PRODUCTOS");

        TextoTotal.setFont(new java.awt.Font("Roboto Black", 1, 14)); // NOI18N
        TextoTotal.setText("TOTAL DE PRODUCTOS EN STOCK");

        javax.swing.GroupLayout TotalPanelLayout = new javax.swing.GroupLayout(TotalPanel);
        TotalPanel.setLayout(TotalPanelLayout);
        TotalPanelLayout.setHorizontalGroup(
            TotalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TxtTotal)
                .addGap(16, 16, 16))
            .addGroup(TotalPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TextoTotal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TotalPanelLayout.setVerticalGroup(
            TotalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TextoTotal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(TxtTotal)
                .addContainerGap())
        );

        TxtVentas.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TxtVentas.setForeground(new java.awt.Color(255, 255, 255));
        TxtVentas.setText("Productos");

        Atras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-volver-25.png"))); // NOI18N
        Atras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AtrasMouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-producto-40.png"))); // NOI18N

        javax.swing.GroupLayout EncabezadoPAnelLayout = new javax.swing.GroupLayout(EncabezadoPAnel);
        EncabezadoPAnel.setLayout(EncabezadoPAnelLayout);
        EncabezadoPAnelLayout.setHorizontalGroup(
            EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(Atras)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TxtVentas)
                .addGap(18, 18, 18))
        );
        EncabezadoPAnelLayout.setVerticalGroup(
            EncabezadoPAnelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EncabezadoPAnelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(Atras))
            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(TxtVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout BGLayout = new javax.swing.GroupLayout(BG);
        BG.setLayout(BGLayout);
        BGLayout.setHorizontalGroup(
            BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(EncabezadoPAnel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(BGLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TotalPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Tabla, javax.swing.GroupLayout.DEFAULT_SIZE, 811, Short.MAX_VALUE))
                .addGap(29, 29, 29))
        );
        BGLayout.setVerticalGroup(
            BGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BGLayout.createSequentialGroup()
                .addComponent(EncabezadoPAnel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Tabla, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TotalPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void AtrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AtrasMouseClicked
        Prin p = new Prin();
        p.setVisible(true);
        
    }//GEN-LAST:event_AtrasMouseClicked

    private Set<String> productosRegistrados = new HashSet<String>();
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Atras;
    private javax.swing.JPanel BG;
    private javax.swing.JPanel EncabezadoPAnel;
    private javax.swing.JScrollPane Tabla;
    private javax.swing.JLabel TextoTotal;
    private javax.swing.JPanel TotalPanel;
    private javax.swing.JLabel TxtTotal;
    private javax.swing.JLabel TxtVentas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTable visor;
    // End of variables declaration//GEN-END:variables

   
   
    
}
