/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.ArrayList;

/**
 *
 * @author edwin
 */
public class LIsta_precio {
    ArrayList<Precio>lista;
    
    public LIsta_precio(){
    lista= new ArrayList<>();
    }
    
    public void AgregarPRecios(Precio p){
    lista.add(p);
    }
}
