
package Clases;


public class Precio {
 private String precio;

    public Precio() {
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public Precio(String precio) {
        this.precio = precio;
    }
 
 
}
