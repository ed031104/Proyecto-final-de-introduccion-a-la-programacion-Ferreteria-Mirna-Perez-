/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;


public class Productos {
    private int id;
    private String nom_producto;

    public Productos() {
    }

    public Productos(int id, String nom_producto){
    this.id = id;
    this.nom_producto = nom_producto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProducto() {
        return nom_producto;
    }

    public void setProducto(String producto) {
        this.nom_producto = producto;
    }
    
    
}
