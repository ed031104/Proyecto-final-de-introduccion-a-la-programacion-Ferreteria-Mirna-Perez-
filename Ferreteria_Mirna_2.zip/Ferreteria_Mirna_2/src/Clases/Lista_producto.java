
package Clases;

import java.util.ArrayList;


public class Lista_producto {
    ArrayList<Productos>lista;
    
    public Lista_producto(){
        lista = new ArrayList<>();
    }
    
    public void AgregarProductos(Productos p) {   //mirar el minuto 4:37 del video llenar Jcombox con base de datos - apache netbeans y mysql
    lista.add(p);
    }
    
    
}
